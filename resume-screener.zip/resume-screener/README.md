# Sift — AI Resume Screening System

Rank a batch of resumes against a single job description using a **hybrid scoring pipeline**:
semantic similarity (Sentence Transformer embeddings) + skill-keyword coverage + fuzzy text
overlap, with an optional **LLM rationale** explaining why each candidate ranks where they do.

Built with FastAPI + a zero-dependency HTML/JS frontend. Runs entirely on your machine.

---

## What it does

1. Upload a job description + a stack of resumes (PDF / DOCX / TXT).
2. Each resume is parsed to text, embedded, and scored against the JD on three axes:
   - **Semantic fit** (55%) — cosine similarity of embeddings, catches meaning beyond keywords.
   - **Skill coverage** (35%) — how many required skills appear (exact or fuzzy match).
   - **Text overlap** (10%) — token-set fuzzy ratio as a tiebreaker.
3. Candidates are ranked best-first with a full score breakdown and matched/missing skills.
4. The top-N get a plain-language LLM rationale (works without an API key via a fallback summary).

---

## Project structure

```
resume-screener/
├── backend/
│   ├── main.py                 # FastAPI app + routes, also serves the frontend
│   ├── requirements.txt
│   └── services/
│       ├── parser.py           # PDF / DOCX / TXT -> text
│       ├── scorer.py           # hybrid scoring + ranking
│       └── explainer.py        # Claude LLM rationale (+ offline fallback)
├── frontend/
│   └── index.html              # single-page UI (drag-drop, results)
└── sample_data/                # a JD + 3 example resumes to test with
```

---

## Run it (VS Code)

From the project root:

```bash
cd backend
python -m venv venv

# Windows
venv\Scripts\activate
# macOS / Linux
source venv/bin/activate

pip install -r requirements.txt
uvicorn main:app --reload --port 8000
```

Open **http://localhost:8000** in your browser. That's the whole app — backend and UI on one URL.

> First run downloads the `all-MiniLM-L6-v2` embedding model (~90 MB) once, then caches it.

### Try it fast
Paste `sample_data/job_description.txt` into the role box and upload the three
`sample_data/candidate_*.txt` files. Candidate A should rank #1.

---

## Enable real LLM rationales (optional)

Without a key, the app generates a deterministic summary so it works out of the box.
To get Claude-written rationales, set an API key before launching:

```bash
# macOS / Linux
export ANTHROPIC_API_KEY=sk-ant-...
# Windows
set ANTHROPIC_API_KEY=sk-ant-...
```

---

## How scoring works

Final score = `0.55·semantic + 0.35·skill_coverage + 0.10·fuzzy`, scaled to 0–100.
Weights live at the top of `services/scorer.py` — tune them per role.

- **Semantic** uses normalized embeddings, so cosine similarity is a plain dot product.
- **Skills** are taken from the optional "must-have skills" field; if left blank, they're
  auto-extracted from the JD. Matching is substring OR fuzzy (`partial_ratio >= 90`) to
  handle variants like "scikit-learn" vs "sklearn".

---

## Notes & next steps

- Stateless and in-memory — nothing is stored. Add a DB to persist screening runs.
- For large batches, swap the brute-force similarity for a FAISS index.
- Add bias-mitigation (strip name/gender/age before scoring) for fair-hiring compliance.
