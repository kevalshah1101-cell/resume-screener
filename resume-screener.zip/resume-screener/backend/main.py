"""AI Resume Screening System - FastAPI backend."""
from fastapi import FastAPI, UploadFile, File, Form, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from typing import List

from services.parser import extract_text
from services.scorer import rank_resumes
from services.explainer import explain

app = FastAPI(title="AI Resume Screener")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

FRONTEND_DIR = Path(__file__).resolve().parent.parent / "frontend"


@app.get("/api/health")
def health():
    return {"status": "ok"}


@app.post("/api/screen")
async def screen(
    job_description: str = Form(...),
    skills: str = Form(""),
    explain_top: int = Form(3),
    resumes: List[UploadFile] = File(...),
):
    if not job_description.strip():
        raise HTTPException(400, "Job description is required.")
    if not resumes:
        raise HTTPException(400, "Upload at least one resume.")

    parsed = []
    errors = []
    for f in resumes:
        try:
            content = await f.read()
            text = extract_text(f.filename, content)
            if text:
                parsed.append({"name": f.filename, "text": text})
            else:
                errors.append(f"{f.filename}: no extractable text")
        except Exception as e:
            errors.append(f"{f.filename}: {e}")

    if not parsed:
        raise HTTPException(400, f"No readable resumes. {errors}")

    ranked = rank_resumes(job_description, parsed, skills)

    # Generate LLM rationale only for the top-N to save cost/time
    for i, cand in enumerate(ranked):
        if i < explain_top:
            cand["rationale"] = explain(job_description, cand)
        else:
            cand["rationale"] = None
        cand.pop("text", None)  # don't ship full resume text back

    return {"count": len(ranked), "errors": errors, "results": ranked}


# Serve the frontend (so you can open one URL and use the app)
if FRONTEND_DIR.exists():
    app.mount("/static", StaticFiles(directory=FRONTEND_DIR), name="static")

    @app.get("/")
    def index():
        return FileResponse(FRONTEND_DIR / "index.html")
