"""Optional LLM layer: generates a plain-language rationale for each ranking.

Works without an API key (returns a deterministic fallback summary), so the app
runs out of the box. Set ANTHROPIC_API_KEY to enable real LLM rationales.
"""
import os
from typing import Dict

try:
    from anthropic import Anthropic
except Exception:  # library optional at runtime
    Anthropic = None

MODEL = "claude-sonnet-4-6"


def _client():
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key or Anthropic is None:
        return None
    return Anthropic(api_key=key)


def explain(jd_text: str, candidate: Dict) -> str:
    client = _client()
    if client is None:
        return _fallback(candidate)

    prompt = (
        "You are an expert technical recruiter. Given a job description and a candidate's "
        "match breakdown, write a concise 2-3 sentence rationale: why they rank where they do, "
        "their strongest fit, and the single biggest gap. Be direct.\n\n"
        f"JOB DESCRIPTION:\n{jd_text[:2000]}\n\n"
        f"CANDIDATE: {candidate['name']}\n"
        f"Overall match: {candidate['score']}%\n"
        f"Semantic fit: {candidate['semantic']}%\n"
        f"Skill coverage: {candidate['skill_coverage']}%\n"
        f"Matched skills: {', '.join(candidate['matched_skills'][:15]) or 'none'}\n"
        f"Missing skills: {', '.join(candidate['missing_skills'][:15]) or 'none'}\n\n"
        f"RESUME EXCERPT:\n{candidate['text'][:1500]}"
    )
    try:
        resp = client.messages.create(
            model=MODEL,
            max_tokens=250,
            messages=[{"role": "user", "content": prompt}],
        )
        return resp.content[0].text.strip()
    except Exception as e:
        return _fallback(candidate) + f"  (LLM unavailable: {e})"


def _fallback(candidate: Dict) -> str:
    matched = ", ".join(candidate["matched_skills"][:5]) or "few listed skills"
    missing = ", ".join(candidate["missing_skills"][:3]) or "none notable"
    return (
        f"{candidate['name']} scores {candidate['score']}% overall, with strong semantic "
        f"alignment ({candidate['semantic']}%) and {candidate['skill_coverage']}% skill coverage. "
        f"Key strengths: {matched}. Notable gaps: {missing}."
    )
