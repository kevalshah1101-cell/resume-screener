"""Hybrid scoring: semantic similarity + skill keyword overlap + edit-distance fuzzy match."""
import re
from functools import lru_cache
from typing import List, Dict

import numpy as np
from rapidfuzz import fuzz
from sentence_transformers import SentenceTransformer

# Weights for the final composite score
W_SEMANTIC = 0.55
W_SKILL = 0.35
W_FUZZY = 0.10


@lru_cache(maxsize=1)
def _model() -> SentenceTransformer:
    # Loaded once, cached. Small + fast, good enough for screening.
    return SentenceTransformer("all-MiniLM-L6-v2")


def _embed(texts: List[str]) -> np.ndarray:
    return _model().encode(texts, normalize_embeddings=True)


def _semantic_scores(jd_text: str, resume_texts: List[str]) -> np.ndarray:
    vecs = _embed([jd_text] + resume_texts)
    jd_vec, res_vecs = vecs[0], vecs[1:]
    # cosine similarity (vectors already normalized) -> [0, 1]
    sims = res_vecs @ jd_vec
    return np.clip(sims, 0, 1)


def extract_skills(jd_text: str, skills_csv: str = "") -> List[str]:
    """Use the explicit skills list if provided, else pull capitalized/known tokens from the JD."""
    if skills_csv.strip():
        return [s.strip().lower() for s in skills_csv.split(",") if s.strip()]
    # crude fallback: grab multi-word tech-ish phrases and known keywords
    tokens = re.findall(r"[A-Za-z][A-Za-z0-9+#.\-]{1,}", jd_text)
    seen, skills = set(), []
    for t in tokens:
        tl = t.lower()
        if len(tl) >= 3 and tl not in seen:
            seen.add(tl)
            skills.append(tl)
    return skills[:40]


def _skill_match(resume_text: str, skills: List[str]) -> Dict:
    rl = resume_text.lower()
    matched, missing = [], []
    for sk in skills:
        # direct substring OR strong fuzzy token match
        if sk in rl or fuzz.partial_ratio(sk, rl) >= 90:
            matched.append(sk)
        else:
            missing.append(sk)
    coverage = len(matched) / len(skills) if skills else 0.0
    return {"matched": matched, "missing": missing, "coverage": coverage}


def _fuzzy_overall(jd_text: str, resume_text: str) -> float:
    return fuzz.token_set_ratio(jd_text, resume_text) / 100.0


def rank_resumes(jd_text: str, resumes: List[Dict], skills_csv: str = "") -> List[Dict]:
    """resumes: [{'name': str, 'text': str}, ...]  ->  ranked list with score breakdown."""
    if not resumes:
        return []

    skills = extract_skills(jd_text, skills_csv)
    texts = [r["text"] for r in resumes]
    sem = _semantic_scores(jd_text, texts)

    results = []
    for i, r in enumerate(resumes):
        sk = _skill_match(r["text"], skills)
        fuzzy = _fuzzy_overall(jd_text, r["text"])
        composite = (
            W_SEMANTIC * float(sem[i])
            + W_SKILL * sk["coverage"]
            + W_FUZZY * fuzzy
        )
        results.append({
            "name": r["name"],
            "score": round(composite * 100, 1),
            "semantic": round(float(sem[i]) * 100, 1),
            "skill_coverage": round(sk["coverage"] * 100, 1),
            "fuzzy": round(fuzzy * 100, 1),
            "matched_skills": sk["matched"],
            "missing_skills": sk["missing"],
            "text": r["text"],
        })

    results.sort(key=lambda x: x["score"], reverse=True)
    for rank, r in enumerate(results, 1):
        r["rank"] = rank
    return results
